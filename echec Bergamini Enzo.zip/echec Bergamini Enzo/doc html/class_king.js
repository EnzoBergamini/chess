var class_king =
[
    [ "King", "class_king.html#a96b9223e315a7b7b30bafddaa17268ab", null ],
    [ "isLegalMove", "class_king.html#a7337f2489ef0d4dc23a92697a5cf76e6", null ]
];