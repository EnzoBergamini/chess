var hierarchy =
[
    [ "Echiquier", "class_echiquier.html", null ],
    [ "Jeu", "class_jeu.html", null ],
    [ "Piece", "class_piece.html", [
      [ "Bishop", "class_bishop.html", null ],
      [ "King", "class_king.html", null ],
      [ "Knight", "class_knight.html", null ],
      [ "Pawn", "class_pawn.html", null ],
      [ "Queen", "class_queen.html", null ],
      [ "Rook", "class_rook.html", null ]
    ] ],
    [ "Square", "class_square.html", null ]
];