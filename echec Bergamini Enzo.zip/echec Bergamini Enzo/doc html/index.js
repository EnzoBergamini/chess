var index =
[
    [ "Résumé général", "index.html#Résumé_général", null ],
    [ "Introduction", "index.html#Section_introduction", null ]
];