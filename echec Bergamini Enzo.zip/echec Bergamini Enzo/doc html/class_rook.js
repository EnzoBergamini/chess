var class_rook =
[
    [ "Rook", "class_rook.html#a4e6a16d2b518665d5d2ee638f8ec3b73", null ],
    [ "isLegalMove", "class_rook.html#aee556a74be6ca9a24bb21141a2bd1952", null ]
];