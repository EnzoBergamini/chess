var _input_8cpp =
[
    [ "isDrawInput", "_input_8cpp.html#a18473d9c77c3668e9acd8a8a9503e565", null ],
    [ "isQuitInput", "_input_8cpp.html#ad7227221b4de6dc9f805a6031a0e3e48", null ],
    [ "isResignInput", "_input_8cpp.html#a1af6c704c0f97292ab8db2cb5c435104", null ],
    [ "isValidBigRookMove", "_input_8cpp.html#a35898c86c806c3145ca1db207e14b51f", null ],
    [ "isValidBishopPromotion", "_input_8cpp.html#ac50d40083d2dca3f675a9267853411c2", null ],
    [ "isValidInput", "_input_8cpp.html#a9d1265ac709651f7702c7a5ba0a11238", null ],
    [ "isValidKnightPromotion", "_input_8cpp.html#a19032eeb87a4ec79b0d9ce886ab75a03", null ],
    [ "isValidMoveInput", "_input_8cpp.html#a1e00530b569554cc5f19750d3330c281", null ],
    [ "isValidPromotion", "_input_8cpp.html#af0669257f4d91e82b9c6f6afec907a40", null ],
    [ "isValidQueenPromotion", "_input_8cpp.html#a98a825542e35f663a4d9845fe18ee023", null ],
    [ "isValidRookPromotion", "_input_8cpp.html#ae49b6bb3e1ae7023e417b1bd03045148", null ],
    [ "isValidSmallRookMove", "_input_8cpp.html#ad73d51b7f71e4d68ae802c3dbba844ca", null ]
];