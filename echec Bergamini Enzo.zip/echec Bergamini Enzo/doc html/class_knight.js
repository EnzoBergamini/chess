var class_knight =
[
    [ "Knight", "class_knight.html#ad287a624bd7c84f0286993c059875645", null ],
    [ "isLegalMove", "class_knight.html#ab737014acfaa403274d51dc6a88ca5b9", null ]
];