var _king_8h =
[
    [ "King", "class_king.html", "class_king" ]
];