var _square_8cpp =
[
    [ "BOARD_SIZE", "_square_8cpp.html#a1db39eb31d1315ce982608fe25587b6d", null ]
];