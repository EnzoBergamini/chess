var searchData=
[
  ['bigrookmove_0',['bigRookMove',['../class_jeu.html#aff51e9eba6e8e6adfdc5fac133863dfe',1,'Jeu']]],
  ['bishop_1',['Bishop',['../class_bishop.html#a43d9b099b0f658871c9a2cd55628afaf',1,'Bishop']]]
];
