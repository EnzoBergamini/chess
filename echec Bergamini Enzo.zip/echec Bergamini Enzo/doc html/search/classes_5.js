var searchData=
[
  ['queen_0',['Queen',['../class_queen.html',1,'']]]
];
