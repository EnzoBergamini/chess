var searchData=
[
  ['last_5fmove_0',['last_move',['../class_jeu.html#a9914987ff4d45bd652f1bbb9dd584c74',1,'Jeu']]],
  ['line_1',['line',['../class_square.html#af37b0659384cd9b61d594f64da5641e8',1,'Square']]]
];
