var searchData=
[
  ['move_5fcount_0',['move_count',['../class_piece.html#a5556d6a3db34ca7c6d486d2f9ceae0c9',1,'Piece']]]
];
