var searchData=
[
  ['getcatch_0',['getCatch',['../class_piece.html#a229b7b5217941c9b08c5b169a8152b47',1,'Piece']]],
  ['getcolor_1',['getColor',['../class_piece.html#a3c662c72321c3459e4c8581801829e54',1,'Piece']]],
  ['getcolumn_2',['getColumn',['../class_square.html#a8c17a73ee7627d8fbafceff1d22d09fc',1,'Square']]],
  ['getid_3',['getId',['../class_piece.html#ad67133f2d7563df69a0912c47ae0cc6f',1,'Piece']]],
  ['getkingsquare_4',['getKingSquare',['../class_echiquier.html#a28572bea53ff6f7c7137bf41994d17d3',1,'Echiquier']]],
  ['getlastmove_5',['getLastMove',['../class_jeu.html#a68399e7698517e54a22c69173ebe88c3',1,'Jeu']]],
  ['getline_6',['getLine',['../class_square.html#af6fc96300b5d4473325d843d628579cf',1,'Square']]],
  ['getmovecount_7',['getMoveCount',['../class_piece.html#a57664afd718c1fc8ce84be728ab06241',1,'Piece']]],
  ['getname_8',['getName',['../class_piece.html#a9a913c322dbd817d69549602c5839a55',1,'Piece']]],
  ['getpiece_9',['getPiece',['../class_echiquier.html#af27b29c4ceb9fd648a4e016d6d7fdeae',1,'Echiquier']]],
  ['getplayer_10',['getPlayer',['../class_jeu.html#aef7d15305979850448a0623f6e8d51d9',1,'Jeu']]],
  ['getsquare_11',['getSquare',['../class_piece.html#ae52476d1bc47b9f084da6ed744192537',1,'Piece']]]
];
