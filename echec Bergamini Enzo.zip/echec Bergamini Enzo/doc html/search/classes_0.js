var searchData=
[
  ['bishop_0',['Bishop',['../class_bishop.html',1,'']]]
];
