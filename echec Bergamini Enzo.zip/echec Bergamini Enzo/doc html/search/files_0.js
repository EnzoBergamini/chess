var searchData=
[
  ['bishop_2ecpp_0',['Bishop.cpp',['../_bishop_8cpp.html',1,'']]],
  ['bishop_2eh_1',['Bishop.h',['../_bishop_8h.html',1,'']]]
];
