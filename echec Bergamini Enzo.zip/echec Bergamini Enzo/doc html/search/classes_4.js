var searchData=
[
  ['pawn_0',['Pawn',['../class_pawn.html',1,'']]],
  ['piece_1',['Piece',['../class_piece.html',1,'']]]
];
