var searchData=
[
  ['id_0',['id',['../class_piece.html#ac40cffee50da10a50361ff4791fdd528',1,'Piece']]],
  ['is_5fcatch_1',['is_catch',['../class_piece.html#abf9583545849b0ad01cffeed5d9740e0',1,'Piece']]]
];
