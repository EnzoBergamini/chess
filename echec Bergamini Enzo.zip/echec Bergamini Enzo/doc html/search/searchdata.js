var indexSectionsWithContent =
{
  0: "abcdegijklmnopqrsw~",
  1: "bejkpqrs",
  2: "bceijkmpqrs",
  3: "abcdegijkmopqrs~",
  4: "ceilmnp",
  5: "c",
  6: "bw",
  7: "b",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

