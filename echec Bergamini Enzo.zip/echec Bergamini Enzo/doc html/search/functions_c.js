var searchData=
[
  ['queen_0',['Queen',['../class_queen.html#a90677ddf0a1cacc3ec891e3e605e14ae',1,'Queen']]]
];
