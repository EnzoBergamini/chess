var searchData=
[
  ['king_0',['King',['../class_king.html#a96b9223e315a7b7b30bafddaa17268ab',1,'King']]],
  ['knight_1',['Knight',['../class_knight.html#ad287a624bd7c84f0286993c059875645',1,'Knight']]]
];
