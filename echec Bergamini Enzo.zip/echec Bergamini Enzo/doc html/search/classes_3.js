var searchData=
[
  ['king_0',['King',['../class_king.html',1,'']]],
  ['knight_1',['Knight',['../class_knight.html',1,'']]]
];
