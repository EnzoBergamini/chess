var searchData=
[
  ['queen_2ecpp_0',['Queen.cpp',['../_queen_8cpp.html',1,'']]],
  ['queen_2eh_1',['Queen.h',['../_queen_8h.html',1,'']]]
];
