var searchData=
[
  ['pieces_0',['pieces',['../class_echiquier.html#a8b1ca00d548faf45d7e8f0311c0f9e03',1,'Echiquier']]],
  ['position_1',['position',['../class_piece.html#a3bfe047bbab090fa920f2ed4d8453a59',1,'Piece']]]
];
