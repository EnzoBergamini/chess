var searchData=
[
  ['name_0',['name',['../class_piece.html#a4cfa0ffac54632f92ac06f50b72e9335',1,'Piece']]]
];
