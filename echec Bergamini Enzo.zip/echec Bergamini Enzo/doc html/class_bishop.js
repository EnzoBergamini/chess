var class_bishop =
[
    [ "Bishop", "class_bishop.html#a43d9b099b0f658871c9a2cd55628afaf", null ],
    [ "isLegalMove", "class_bishop.html#ac5df2a83a21a4f05bfd6f56d271cdd9f", null ]
];