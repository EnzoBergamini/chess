var _queen_8h =
[
    [ "Queen", "class_queen.html", "class_queen" ]
];