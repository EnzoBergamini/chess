var annotated_dup =
[
    [ "Bishop", "class_bishop.html", "class_bishop" ],
    [ "Echiquier", "class_echiquier.html", "class_echiquier" ],
    [ "Jeu", "class_jeu.html", "class_jeu" ],
    [ "King", "class_king.html", "class_king" ],
    [ "Knight", "class_knight.html", "class_knight" ],
    [ "Pawn", "class_pawn.html", "class_pawn" ],
    [ "Piece", "class_piece.html", "class_piece" ],
    [ "Queen", "class_queen.html", "class_queen" ],
    [ "Rook", "class_rook.html", "class_rook" ],
    [ "Square", "class_square.html", "class_square" ]
];