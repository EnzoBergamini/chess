var class_pawn =
[
    [ "Pawn", "class_pawn.html#ae3f368630f9c322ee6eee4f95c23b8d2", null ],
    [ "isLegalMove", "class_pawn.html#a17c300a121478d434a553fc56a085976", null ]
];